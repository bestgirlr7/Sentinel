import React, { useEffect, useMemo, useRef, useState } from 'react'
import MapGL, { FullscreenControl, Layer, Marker, NavigationControl, Popup, ScaleControl, Source } from 'react-map-gl/maplibre'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Activity, AlertTriangle, Ambulance, BadgeIndianRupee, BedDouble, BellRing, Building2,
  Cross, Droplets, Flame, HeartPulse, History, Hospital, Landmark, MapPinned, Menu,
  Pause, Play, RefreshCw, Route, Shield, Siren, SlidersHorizontal, Stethoscope,
  Users, Waypoints, X, Zap, ChevronRight, CircleDollarSign, TrendingUp, Pill,
  Radio, MapPin, Clock3, ShieldCheck, Heart, Navigation, UserRoundPlus, Gauge
} from 'lucide-react'
import {
  Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis, BarChart, Bar
} from 'recharts'

type Severity = 'CRITICAL' | 'SEVERE' | 'MODERATE' | 'STABLE'
type Page = 'Dashboard' | 'Simulation' | 'Patients' | 'Hospitals' | 'Resources' | 'Ambulances' | 'Map & Routes' | 'Funds' | 'Allocation Decisions' | 'Decision History'
type HospitalStatus = 'Available' | 'Limited' | 'Critical' | 'Offline'
type RoadState = 'CLEAR' | 'SLOW' | 'DAMAGED' | 'BLOCKED' | 'HIGH-RISK'
type Disaster = 'Earthquake' | 'Flood' | 'Fire' | 'Cyclone' | 'Building Collapse' | 'Industrial Accident' | 'Terrorist Attack'

interface HospitalModel {
  id: string; name: string; lat: number; lng: number; totalBeds: number; availableBeds: number;
  icuTotal: number; icuAvailable: number; blood: number; ventilators: number; specialists: string[];
  status: HospitalStatus; currentPatients: number; incoming: number;
}
interface PatientModel {
  id: string; age: number; condition: string; severity: Severity; score: number; lat: number; lng: number;
  icu: boolean; ventilator: boolean; blood: number; specialist: string; ambulanceNeed: 'BASIC'|'ALS'|'ICU'|'NEONATAL';
  assignedHospital?: string; assignedAmbulance?: string; eta?: number; status: string;
}
interface AmbulanceModel {
  id: string; type: 'BASIC'|'ALS'|'ICU'|'NEONATAL'; lat: number; lng: number; available: boolean; equipment: string[]; patient?: string; destination?: string; eta?: number;
}
interface AlertItem { id: number; kind: 'critical'|'warn'|'info'|'success'; text: string; time: string }
interface FacilityModel { id:string; type:'fire'|'police'|'blood'|'ngo'; name:string; lat:number; lng:number; address:string; status:string }
interface Decision { id: string; patientId: string; severity: Severity; ambulance: string; hospital: string; route: string; eta: number; reason: string[]; status: string }

const severityRank: Record<Severity, number> = { CRITICAL: 4, SEVERE: 3, MODERATE: 2, STABLE: 1 }
const sevColor: Record<Severity, string> = { CRITICAL: '#ff4d63', SEVERE: '#ff8a3d', MODERATE: '#ffd166', STABLE: '#35d07f' }
const roadPenalty: Record<RoadState, number> = { CLEAR: 1, SLOW: 1.35, DAMAGED: 1.7, BLOCKED: 99, 'HIGH-RISK': 1.55 }

const hospitalsSeed: HospitalModel[] = [
  { id:'H1', name:'Bharatratna Dr Babasaheb Ambedkar Municipal General Hospital (Shatabdi)', lat:19.2079, lng:72.8510, totalBeds:320, availableBeds:64, icuTotal:42, icuAvailable:9, blood:128, ventilators:12, specialists:['Trauma','Cardiac','Neuro'], status:'Available', currentPatients:256, incoming:3 },
  { id:'H2', name:'Kokilaben Dhirubhai Ambani Hospital', lat:19.13105, lng:72.82505, totalBeds:300, availableBeds:41, icuTotal:38, icuAvailable:7, blood:96, ventilators:10, specialists:['Trauma','Ortho','Neuro','Cardiac'], status:'Available', currentPatients:259, incoming:5 },
  { id:'H3', name:'Nanavati Max Super Speciality Hospital', lat:19.095786, lng:72.839986, totalBeds:350, availableBeds:38, icuTotal:36, icuAvailable:5, blood:82, ventilators:8, specialists:['Trauma','Cardiac','Neuro'], status:'Limited', currentPatients:312, incoming:6 },
  { id:'H4', name:'Dr R. N. Cooper Municipal General Hospital', lat:19.1075, lng:72.8368, totalBeds:260, availableBeds:40, icuTotal:34, icuAvailable:8, blood:112, ventilators:9, specialists:['Trauma','Burns','Cardiac'], status:'Available', currentPatients:220, incoming:2 },
  { id:'H5', name:'Holy Spirit Hospital & Research Centre', lat:19.12833, lng:72.86621, totalBeds:250, availableBeds:19, icuTotal:28, icuAvailable:3, blood:55, ventilators:5, specialists:['Trauma','General','Cardiac'], status:'Limited', currentPatients:231, incoming:7 }
]

const realFacilities: FacilityModel[] = [
  {id:'FIRE-1',type:'fire',name:'Bandra Fire Station',lat:19.05044,lng:72.83756,address:'LK Mehta Marg, Reclamation, Bandra West, Mumbai',status:'Available'},
  {id:'FIRE-2',type:'fire',name:'K/East Ward Mini Fire Station',lat:19.1184,lng:72.8469,address:'Parsi Colony, Gundavali, Andheri East, Mumbai',status:'Available'},
  {id:'POL-1',type:'police',name:'Kandivali Police Station',lat:19.209583,lng:72.85014,address:'S.V. Road, Kandivali West, Mumbai',status:'Deployed'},
  {id:'POL-2',type:'police',name:'D. N. Nagar Police Station',lat:19.1261,lng:72.8313,address:'Andheri West, Mumbai',status:'Available'},
  {id:'BLOOD-1',type:'blood',name:'Kokilaben Dhirubhai Ambani Hospital Blood Bank',lat:19.13105,lng:72.82505,address:'Four Bungalows, Andheri West, Mumbai',status:'Stocks monitored'},
  {id:'BLOOD-2',type:'blood',name:'Holy Spirit Hospital Blood Bank',lat:19.12833,lng:72.86621,address:'Mahakali Caves Road, Andheri East, Mumbai',status:'Stocks monitored'},
  {id:'NGO-1',type:'ngo',name:'Indian Red Cross Society – Mumbai',lat:18.9684,lng:72.8246,address:'Dr. Anandrao Nair Marg, Mumbai Central East, Mumbai',status:'Relief coordination'}
]

const roadNetworkSeed = [
  {id:'R-WEH',name:'Western Express Highway',state:'CLEAR',coords:[[72.8560,19.096],[72.8568,19.125],[72.8574,19.155],[72.8582,19.185],[72.8590,19.215]]},
  {id:'R-SV',name:'S.V. Road Relief Corridor',state:'SLOW',coords:[[72.8399,19.0958],[72.8380,19.125],[72.8420,19.160],[72.8460,19.190],[72.8501,19.2096]]},
  {id:'R-LINK',name:'New Link Road Response Lane',state:'DAMAGED',coords:[[72.8249,19.131],[72.8255,19.155],[72.8288,19.180],[72.8315,19.205]]},
  {id:'R-21',name:'Impact-Zone Connector R-21',state:'BLOCKED',coords:[[72.842,19.142],[72.851,19.148],[72.861,19.154],[72.870,19.160]]}
]


const patientsSeed: PatientModel[] = [
  { id:'P-104', age:41, condition:'Crush injury + respiratory distress', severity:'CRITICAL', score:96, lat:19.1365, lng:72.8500, icu:true, ventilator:true, blood:2, specialist:'Trauma', ambulanceNeed:'ICU', status:'Awaiting allocation' },
  { id:'P-118', age:29, condition:'Severe head trauma', severity:'CRITICAL', score:92, lat:19.1590, lng:72.8420, icu:true, ventilator:false, blood:1, specialist:'Neuro', ambulanceNeed:'ALS', status:'Awaiting allocation' },
  { id:'P-125', age:67, condition:'Chest trauma, unstable vitals', severity:'SEVERE', score:82, lat:19.1100, lng:72.8590, icu:true, ventilator:false, blood:1, specialist:'Cardiac', ambulanceNeed:'ALS', status:'Awaiting allocation' },
  { id:'P-132', age:34, condition:'Open fracture', severity:'SEVERE', score:73, lat:19.1510, lng:72.8780, icu:false, ventilator:false, blood:1, specialist:'Trauma', ambulanceNeed:'ALS', status:'Awaiting allocation' },
  { id:'P-141', age:23, condition:'Lacerations + dehydration', severity:'MODERATE', score:54, lat:19.1280, lng:72.8300, icu:false, ventilator:false, blood:0, specialist:'General', ambulanceNeed:'BASIC', status:'Awaiting allocation' },
  { id:'P-149', age:12, condition:'Minor smoke inhalation', severity:'STABLE', score:28, lat:19.1680, lng:72.8690, icu:false, ventilator:false, blood:0, specialist:'Pediatrics', ambulanceNeed:'BASIC', status:'Awaiting allocation' },
]
const ambulancesSeed: AmbulanceModel[] = [
  { id:'A-03', type:'BASIC', lat:19.121, lng:72.838, available:true, equipment:['Oxygen','First aid'] },
  { id:'A-07', type:'ICU', lat:19.143, lng:72.861, available:true, equipment:['Ventilator','Defibrillator','Multiparameter monitor'] },
  { id:'A-11', type:'ALS', lat:19.105, lng:72.852, available:true, equipment:['Cardiac monitor','Airway kit','IV pump'] },
  { id:'A-16', type:'ALS', lat:19.174, lng:72.849, available:true, equipment:['Cardiac monitor','Trauma kit','Oxygen'] },
  { id:'A-21', type:'NEONATAL', lat:19.132, lng:72.889, available:true, equipment:['Infant warmer','Neonatal ventilator'] },
  { id:'A-24', type:'BASIC', lat:19.156, lng:72.887, available:true, equipment:['Oxygen','First aid'] },
]

const pages: {name:Page, icon:React.ComponentType<any>}[] = [
  {name:'Dashboard',icon:Activity},{name:'Simulation',icon:Siren},{name:'Patients',icon:HeartPulse},{name:'Hospitals',icon:Hospital},
  {name:'Resources',icon:BoxesIcon},{name:'Ambulances',icon:Ambulance},{name:'Map & Routes',icon:MapPinned},{name:'Funds',icon:BadgeIndianRupee},
  {name:'Allocation Decisions',icon:Waypoints},{name:'Decision History',icon:History},
]
function BoxesIcon(props:any){ return <Landmark {...props}/> }

function nowTime(){ return new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'}) }
function haversine(a:{lat:number,lng:number}, b:{lat:number,lng:number}) {
  const R=6371, dLat=(b.lat-a.lat)*Math.PI/180, dLng=(b.lng-a.lng)*Math.PI/180
  const q=Math.sin(dLat/2)**2+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLng/2)**2
  return R*2*Math.atan2(Math.sqrt(q),Math.sqrt(1-q))
}
function zonePolygon(lng:number,lat:number,radiusKm:number,scale:number,seed:number){
  const bearings=[0,34,72,108,151,198,236,281,326,360]
  const wobble=[1.0,.86,1.12,.94,1.07,.9,1.14,.88,1.03,1.0]
  const coords=bearings.map((deg,i)=>{const r=radiusKm*scale*wobble[(i+seed)%wobble.length];const a=deg*Math.PI/180;const dy=(r/110.574)*Math.cos(a);const dx=(r/(111.32*Math.cos(lat*Math.PI/180)))*Math.sin(a);return [lng+dx,lat+dy]})
  return coords
}
function impactZonesGeoJSON(lng:number,lat:number,radiusKm:number,severity:number){
  const severityScale=.85+severity*.08
  return {type:'FeatureCollection' as const,features:[
    {type:'Feature' as const,properties:{level:'warning',label:'Warning / monitoring zone'},geometry:{type:'Polygon' as const,coordinates:[zonePolygon(lng,lat,radiusKm,severityScale,0)]}},
    {type:'Feature' as const,properties:{level:'severe',label:'Severe impact zone'},geometry:{type:'Polygon' as const,coordinates:[zonePolygon(lng,lat,radiusKm*.67,severityScale,2)]}},
    {type:'Feature' as const,properties:{level:'critical',label:'Critical impact zone'},geometry:{type:'Polygon' as const,coordinates:[zonePolygon(lng,lat,radiusKm*.38,severityScale,4)]}}
  ]}
}
function facilitySymbol(type:FacilityModel['type']){ return type==='fire'?'F':type==='police'?'P':type==='blood'?'B':'N' }


export default function App(){
  const [entered,setEntered]=useState(false)
  const [page,setPage]=useState<Page>('Dashboard')
  const [running,setRunning]=useState(false)
  const [speed,setSpeed]=useState<1|2|5|10>(()=>{const saved=Number(localStorage.getItem('sentinel-speed'));return ([1,2,5,10].includes(saved)?saved:1) as 1|2|5|10})
  const [modelRevision,setModelRevision]=useState(0)
  const [demo,setDemo]=useState(false)
  const [elapsed,setElapsed]=useState(0)
  const [disaster,setDisaster]=useState<Disaster>('Earthquake')
  const [severity,setSeverity]=useState(3)
  const [radius,setRadius]=useState(8)
  const [traffic,setTraffic]=useState(2)
  const [road,setRoad]=useState<RoadState>('SLOW')
  const [patients,setPatients]=useState(patientsSeed)
  const [hospitalBaseline,setHospitalBaseline]=useState(hospitalsSeed)
  const [hospitals,setHospitals]=useState(hospitalsSeed)
  const [ambulances,setAmbulances]=useState(ambulancesSeed)
  const [funds,setFunds]=useState({total:5000000,hospital:1200000,ambulance:500000,medicines:800000,rescue:1000000,ngo:400000})
  const [blood,setBlood]=useState(422)
  const [meds,setMeds]=useState(78)
  const [alerts,setAlerts]=useState<AlertItem[]>([
    {id:1,kind:'warn',text:'ICU capacity falling at Civic Relief Hospital.',time:nowTime()},
    {id:2,kind:'critical',text:'Critical patient P-104 detected near impact zone.',time:nowTime()},
    {id:3,kind:'info',text:'SENTINEL decision engine ready.',time:nowTime()},
  ])
  const [decisions,setDecisions]=useState<Decision[]>([])
  const [selectedHospital,setSelectedHospital]=useState<HospitalModel|null>(null)
  const [selectedPatient,setSelectedPatient]=useState<PatientModel|null>(null)
  const demoRef=useRef<number[]>([])
  const lastOperationalTick=useRef(0)

  const epicenter={lat:19.1518,lng:72.8533}
  const pushAlert=(text:string,kind:AlertItem['kind']='info')=>setAlerts(a=>[{id:Date.now()+Math.random(),kind,text,time:nowTime()},...a].slice(0,12))
  const remainingFunds=funds.total-funds.hospital-funds.ambulance-funds.medicines-funds.rescue-funds.ngo
  const availableIcu=hospitals.reduce((s,h)=>s+h.icuAvailable,0)
  const availableAmb=ambulances.filter(a=>a.available).length

  const recompute=(announce=true, overrides?:{patients?:PatientModel[], hospitalBaseline?:HospitalModel[], road?:RoadState, traffic?:number, severity?:number, radius?:number})=>{
    const sourcePatients=overrides?.patients ?? patients
    const sourceHospitals=overrides?.hospitalBaseline ?? hospitalBaseline
    const effectiveRoad=overrides?.road ?? road
    const effectiveTraffic=overrides?.traffic ?? traffic
    const effectiveSeverity=overrides?.severity ?? severity
    const effectiveRadius=overrides?.radius ?? radius
    let hNext=sourceHospitals.map(h=>({...h,incoming:0}))
    let aNext: AmbulanceModel[] = ambulancesSeed.map(a=>({...a, patient:undefined, destination:undefined, eta:undefined, available:true}))
    const ordered=[...sourcePatients].sort((a,b)=>severityRank[b.severity]-severityRank[a.severity] || b.score-a.score)
    const newDecisions:Decision[]=[]
    const pNext=ordered.map(p=>{
      const candidates=hNext.filter(h=>h.status!=='Offline' && h.availableBeds>0).map(h=>{
        const dist=haversine(p,h)
        const roadFactor=roadPenalty[effectiveRoad]
        const trafficFactor=1+(effectiveTraffic-1)*0.22
        const impactFactor=haversine(h,epicenter)<effectiveRadius ? 1+effectiveSeverity*0.08 : 1
        const rawEta=(dist/28)*60*roadFactor*trafficFactor*impactFactor
        const eta=Number.isFinite(rawEta)?Math.max(4,Math.round(rawEta)):999
        const medical=(p.icu?(h.icuAvailable>0?35:-70):15)+(p.ventilator?(h.ventilators>0?20:-60):8)+(h.blood>=p.blood?12:-25)+(h.specialists.includes(p.specialist)?15:0)
        const capacity=Math.max(-25,20-(h.incoming*2)+(h.availableBeds>10?12:-15))
        const routeScore=effectiveRoad==='BLOCKED'?-100:Math.max(-30,30-eta)
        return {h,dist,eta,score:medical+capacity+routeScore}
      }).sort((a,b)=>b.score-a.score)
      const best=candidates[0]
      const compatibleTypes = p.ambulanceNeed==='ICU'?['ICU']:p.ambulanceNeed==='ALS'?['ALS','ICU']:p.ambulanceNeed==='NEONATAL'?['NEONATAL']:['BASIC','ALS','ICU']
      const amb=aNext.filter(a=>a.available && compatibleTypes.includes(a.type)).sort((a,b)=>haversine(a,p)-haversine(b,p))[0]
      if(!best || !amb || best.score<0) return {...p,status:'Awaiting resources',assignedHospital:undefined,assignedAmbulance:undefined,eta:undefined}
      amb.available=false; amb.patient=p.id; amb.destination=best.h.name; amb.eta=best.eta
      const hi=hNext.findIndex(x=>x.id===best.h.id)
      hNext[hi].incoming+=1
      hNext[hi].availableBeds=Math.max(0,hNext[hi].availableBeds-1)
      if(p.icu) hNext[hi].icuAvailable=Math.max(0,hNext[hi].icuAvailable-1)
      if(p.ventilator) hNext[hi].ventilators=Math.max(0,hNext[hi].ventilators-1)
      hNext[hi].blood=Math.max(0,hNext[hi].blood-p.blood)
      const d:Decision={id:`DEC-2026-${String(4800+newDecisions.length+1).padStart(6,'0')}`,patientId:p.id,severity:p.severity,ambulance:amb.id,hospital:best.h.name,route:effectiveRoad==='CLEAR'?'Route A':'Route B',eta:best.eta,status:'Allocated',reason:[`${p.severity} medical priority`,p.icu?'ICU capacity confirmed':'General emergency bed available',p.ventilator?'Ventilator available':'Required equipment available',`Blood stock ${best.h.blood>=p.blood?'sufficient':'constrained'}`,`${effectiveRoad} road condition`,`${best.eta} min estimated travel time`]}
      newDecisions.push(d)
      return {...p,assignedHospital:best.h.name,assignedAmbulance:amb.id,eta:best.eta,status:'Allocated'}
    })
    const pMap=new Map(pNext.map(p=>[p.id,p]))
    setPatients(sourcePatients.map(p=>pMap.get(p.id) || p))
    setHospitals(hNext); setAmbulances(aNext); setDecisions(newDecisions)
    if(announce) pushAlert(`MODEL UPDATED — ${newDecisions.length} patients allocated; routes and capacity recalculated.`,'success')
  }

  useEffect(()=>{localStorage.setItem('sentinel-speed',String(speed))},[speed])
  const changeSpeed=(next:1|2|5|10)=>{setSpeed(next);pushAlert(`Simulation speed locked at ${next}x.`,'info')}
  const toggleSimulation=()=>{setRunning(v=>{const next=!v;pushAlert(next?`LIVE simulation running at ${speed}x.`:'Simulation paused.','info');return next})}
  const adaptModel=()=>{recompute(true);setModelRevision(r=>r+1);pushAlert(`ADAPT MODEL complete — revision R${modelRevision+1}. Current road, traffic, severity and capacity applied.`,'success')}
  const recalculateNow=()=>{recompute(true);setModelRevision(r=>r+1);pushAlert(`RECALCULATE NOW complete — revision R${modelRevision+1}.`,'success')}
  useEffect(()=>{ if(!running)return; const id=window.setInterval(()=>setElapsed(v=>v+1),1000/speed); return()=>window.clearInterval(id)},[running,speed])
  useEffect(()=>{
    if(!running || elapsed<5)return
    const tick=Math.floor(elapsed/5)
    if(tick<=lastOperationalTick.current)return
    lastOperationalTick.current=tick
    setBlood(v=>Math.max(0,v-1))
    setMeds(v=>Math.max(0,v-(tick%2===0?1:0)))
    recompute(false)
    if(elapsed%20<5) pushAlert(`Live simulation advanced to T+${elapsed}s: resources and allocations refreshed.`,'info')
  },[elapsed,running])
  useEffect(()=>{ if(!entered)return; recompute(false) },[entered,severity,radius,traffic,road,disaster,hospitalBaseline]) // scenario changes re-evaluate safely

  const reset=()=>{ setRunning(false); setDemo(false); demoRef.current.forEach(clearTimeout); demoRef.current=[]; setElapsed(0); lastOperationalTick.current=0; setSeverity(3); setRadius(8); setTraffic(2); setRoad('SLOW'); setPatients(patientsSeed); setHospitalBaseline(hospitalsSeed); setHospitals(hospitalsSeed); setAmbulances(ambulancesSeed); setDecisions([]); setBlood(422); setMeds(78); pushAlert('Simulation reset to Major Urban Earthquake baseline.','info') }
  const triggerIncident=()=>{
    const id=`P-${150+patients.length}`
    const p:PatientModel={id,age:36,condition:'New disaster-zone trauma',severity:'CRITICAL',score:90,lat:epicenter.lat+(Math.random()-.5)*.04,lng:epicenter.lng+(Math.random()-.5)*.04,icu:true,ventilator:false,blood:1,specialist:'Trauma',ambulanceNeed:'ALS',status:'Awaiting allocation'}
    const next=[p,...patients]
    setPatients(next); pushAlert(`New critical patient ${id} entered triage queue.`,'critical'); window.setTimeout(()=>recompute(true,{patients:next}),0)
  }
  const startDemo=()=>{
    reset(); setDemo(true); setRunning(true); setPage('Dashboard'); pushAlert(`DEMO MODE — Major Urban Earthquake response initiated at ${speed}x.`, 'critical')
    const later=(ms:number,fn:()=>void)=>{ const id=window.setTimeout(fn,Math.max(120,ms/speed)); demoRef.current.push(id) }
    later(1200,()=>{setRadius(11); pushAlert('Disaster radius expanded to 11 km.','warn')})
    later(2500,()=>{recompute(); pushAlert('Critical patients prioritized ahead of stable cases.','success')})
    later(4300,()=>{setRoad('BLOCKED'); pushAlert('ROUTE R-21 BLOCKED — earthquake debris detected.','critical')})
    later(5600,()=>{setRoad('DAMAGED'); setTraffic(3); recompute(); pushAlert('ROUTE REPLANNED — alternate damaged-road corridor selected.','warn')})
    later(7600,()=>{setHospitalBaseline(h=>h.map((x,i)=>i===0?{...x,icuAvailable:Math.max(0,x.icuAvailable-5),status:'Limited'}:x)); pushAlert('City General ICU capacity reduced.','warn')})
    later(9000,()=>{recompute(); pushAlert('Patients reallocated after hospital capacity change.','success')})
    later(11200,()=>{setBlood(v=>v-55);setMeds(v=>v-12);setFunds(f=>({...f,ambulance:f.ambulance+120000,rescue:f.rescue+180000})); pushAlert('Resource consumption synchronized across response network.','info')})
    later(13200,()=>{setDemo(false); pushAlert('SENTINEL ADAPTED TO THE NEW SITUATION.','success')})
  }

  const updateSeverity=(id:string,next:Severity)=>{
    const nextPatients=patients.map(p=>p.id===id?{...p,severity:next,score: next==='CRITICAL'?96:next==='SEVERE'?78:next==='MODERATE'?52:28,icu:next==='CRITICAL'?true:(next==='STABLE'?false:p.icu),ambulanceNeed:next==='CRITICAL'?'ICU':next==='SEVERE'?'ALS':'BASIC'} as PatientModel:p)
    setPatients(nextPatients)
    pushAlert(`${id} severity changed to ${next}; allocation recalculation requested.`, next==='CRITICAL'?'critical':'warn')
    window.setTimeout(()=>recompute(true,{patients:nextPatients}),0)
  }

  const prioritizePatients=()=>{
    const next=[...patients].sort((a,b)=>severityRank[b.severity]-severityRank[a.severity] || b.score-a.score)
    setPatients(next)
    pushAlert('Triage queue reprioritized by clinical acuity and severity score.','success')
    window.setTimeout(()=>recompute(true,{patients:next}),0)
  }

  const simulateAdmission=(hospitalId:string)=>{
    const nextBaseline=hospitalBaseline.map(h=>{
      if(h.id!==hospitalId)return h
      const availableBeds=Math.max(0,h.availableBeds-1)
      const icuAvailable=Math.max(0,h.icuAvailable-1)
      const currentPatients=Math.min(h.totalBeds,h.currentPatients+1)
      const occupancy=Math.min(100,Math.max(0,100-(availableBeds/Math.max(1,h.totalBeds))*100))
      const status:HospitalStatus=availableBeds===0||icuAvailable===0?'Critical':occupancy>=90?'Limited':h.status==='Offline'?'Offline':'Available'
      return {...h,availableBeds,icuAvailable,currentPatients,blood:Math.max(0,h.blood-1),status}
    })
    setHospitalBaseline(nextBaseline)
    const h=nextBaseline.find(x=>x.id===hospitalId)
    if(h) pushAlert(`Simulated high-acuity admission at ${h.name}: general bed + ICU capacity consumed and KPIs refreshed.`,'info')
  }

  if(!entered) return <Landing onEnter={()=>{setEntered(true);setTimeout(()=>recompute(false),60)}} onDemo={()=>{setEntered(true);setTimeout(startDemo,100)}} />

  const context={running,setRunning,toggleSimulation,speed,setSpeed,changeSpeed,modelRevision,adaptModel,recalculateNow,disaster,setDisaster,severity,setSeverity,radius,setRadius,traffic,setTraffic,road,setRoad,patients,hospitals,ambulances,funds,setFunds,blood,setBlood,meds,setMeds,alerts,decisions,recompute,triggerIncident,reset,startDemo,updateSeverity,prioritizePatients,simulateAdmission,epicenter,selectedHospital,setSelectedHospital,selectedPatient,setSelectedPatient,pushAlert}
  return <div className="app-shell">
    <Sidebar page={page} setPage={setPage} running={running} severity={severity}/>
    <main className="main">
      <Topbar page={page} running={running} elapsed={elapsed} speed={speed} modelRevision={modelRevision} disaster={disaster} alerts={alerts}/>
      <AnimatePresence mode="wait"><motion.div key={page} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}} transition={{duration:.16}} className="page-wrap">
        {page==='Dashboard' && <Dashboard {...context}/>} 
        {page==='Simulation' && <SimulationPage {...context}/>} 
        {page==='Patients' && <PatientsPage {...context}/>} 
        {page==='Hospitals' && <HospitalsPage {...context}/>} 
        {page==='Resources' && <ResourcesPage {...context}/>} 
        {page==='Ambulances' && <AmbulancesPage {...context}/>} 
        {page==='Map & Routes' && <MapRoutesPage {...context}/>} 
        {page==='Funds' && <FundsPage {...context}/>} 
        {page==='Allocation Decisions' && <DecisionsPage {...context}/>} 
        {page==='Decision History' && <HistoryPage {...context}/>} 
      </motion.div></AnimatePresence>
    </main>
  </div>
}

function Landing({onEnter,onDemo}:{onEnter:()=>void,onDemo:()=>void}){
  return <div className="landing">
    <div className="landing-grid"/>
    <div className="scanline"/>
    <div className="landing-top"><Brand/><span className="eyebrow"><Radio size={13}/> DISASTER RESPONSE SYSTEM / INDIA REGION</span></div>
    <div className="landing-content">
      <motion.div initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} transition={{duration:.6}}>
        <div className="live-pill"><span className="pulse-dot"/> INTELLIGENT COMMAND & CONTROL</div>
        <h1>SENTINEL</h1>
        <h2>Intelligent & Transparent<br/>Disaster Relief Resource Allocation</h2>
        <p>Every patient. Every resource. Every decision — coordinated in real time.</p>
        <div className="landing-actions"><button className="primary xl" onClick={onEnter}>LAUNCH COMMAND CENTER <ChevronRight size={18}/></button><button className="ghost xl" onClick={onDemo}><Play size={17}/> VIEW DEMO SIMULATION</button></div>
      </motion.div>
      <motion.div initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} transition={{duration:.7,delay:.1}} className="landing-radar">
        <div className="radar-ring r1"/><div className="radar-ring r2"/><div className="radar-ring r3"/><div className="radar-sweep"/><div className="radar-core"><ShieldCheck size={42}/><b>RESPONSE<br/>READY</b></div>
        <div className="radar-node n1">HOSPITAL</div><div className="radar-node n2">AMBULANCE</div><div className="radar-node n3">RESCUE</div><div className="radar-node n4">PATIENT</div>
      </motion.div>
    </div>
    <div className="landing-footer"><span>TEAM TECHTONIC</span><span>DECISION ENGINE <b>ONLINE</b></span><span>SIMULATION BUILD 2026.10</span></div>
  </div>
}

function Brand(){ return <div className="brand"><div className="brand-mark"><Shield size={20}/><span/></div><div><b>SENTINEL</b><small>EMERGENCY OPERATIONS</small></div></div> }
function Sidebar({page,setPage,running,severity}:{page:Page,setPage:(p:Page)=>void,running:boolean,severity:number}){
  return <aside className="sidebar"><Brand/><div className="nav-label">COMMAND MODULES</div><nav>{pages.map(({name,icon:Icon})=><button key={name} className={page===name?'active':''} onClick={()=>setPage(name)}><Icon size={17}/><span>{name}</span>{page===name&&<i/>}</button>)}</nav><div className="side-bottom"><div className="mini-status"><span><i className="green"/>SYSTEM STATUS</span><b>ONLINE</b></div><div className="mini-status"><span><i className={running?'cyan':'amber'}/>SIMULATION</span><b>{running?'ACTIVE':'STANDBY'}</b></div><div className="mini-status"><span><i className="red"/>EMERGENCY</span><b>{['LOW','MEDIUM','HIGH','EXTREME'][Math.max(0,severity-1)]}</b></div></div></aside>
}
function Topbar({page,running,elapsed,speed,modelRevision,disaster,alerts}:{page:Page,running:boolean,elapsed:number,speed:number,modelRevision:number,disaster:Disaster,alerts:AlertItem[]}){
  return <header className="topbar"><div><div className="crumb">SENTINEL / <b>{page.toUpperCase()}</b></div><h3>{page==='Dashboard'?'LIVE DISASTER RESPONSE COMMAND CENTER':page.toUpperCase()}</h3></div><div className="top-right"><div className="top-stat"><span>SIM TIME</span><b>{String(Math.floor(elapsed/60)).padStart(2,'0')}:{String(elapsed%60).padStart(2,'0')}</b></div><div className="top-stat"><span>MODEL</span><b>R{modelRevision}</b></div><div className="top-stat"><span>INCIDENT</span><b>{disaster}</b></div><div className={`system-chip ${running?'live':''}`}><span className="pulse-dot"/>{running?`LIVE • ${speed}x`:'SYSTEM ONLINE'}</div><button className="icon-btn"><BellRing size={17}/><em>{alerts.length}</em></button></div></header>
}

function Dashboard(props:any){
  const {patients,hospitals,ambulances,blood,funds,running,setRunning,recompute,reset,startDemo,triggerIncident}=props
  const crit=patients.filter((p:PatientModel)=>p.severity==='CRITICAL').length, icu=hospitals.reduce((s:number,h:HospitalModel)=>s+h.icuAvailable,0), amb=ambulances.filter((a:AmbulanceModel)=>a.available).length, util=Math.round(100*(1-hospitals.reduce((s:number,h:HospitalModel)=>s+h.availableBeds,0)/hospitals.reduce((s:number,h:HospitalModel)=>s+h.totalBeds,0)))
  const rem=funds.total-funds.hospital-funds.ambulance-funds.medicines-funds.rescue-funds.ngo
  return <div className="stack">
    <div className="command-strip"><div><span className="eyebrow">MAJOR URBAN EARTHQUAKE • SCENARIO 01</span><h2>Operational Overview</h2><p>Severity-led triage, capability-aware hospital matching, adaptive routing and auditable allocation decisions.</p></div><div className="actions dashboard-actions"><div className="dash-speed"><span>SPEED</span>{([1,2,5,10] as const).map(x=><button key={x} className={props.speed===x?'active':''} onClick={()=>props.changeSpeed(x)}>{x}x</button>)}</div><button className="ghost" onClick={props.toggleSimulation}>{running?<Pause size={16}/>:<Play size={16}/>} {running?'PAUSE':'RUN SIMULATION'}</button><button className="primary" onClick={props.adaptModel}><Zap size={16}/>ADAPT MODEL</button><button className="demo-btn" onClick={startDemo}><Play size={15}/> START DEMO</button><button className="icon-btn" title="reset" onClick={reset}><RefreshCw size={16}/></button></div></div>
    <div className="kpi-grid"><Kpi icon={Siren} label="ACTIVE INCIDENTS" value="01" tone="red" sub="Major earthquake"/><Kpi icon={HeartPulse} label="CRITICAL PATIENTS" value={crit} tone="red" sub={`${patients.length} active patients`}/><Kpi icon={BedDouble} label="AVAILABLE ICU BEDS" value={icu} tone="cyan" sub="Across 5 hospitals"/><Kpi icon={Ambulance} label="AVAILABLE AMBULANCES" value={amb} tone="green" sub={`${ambulances.length-amb} currently tasked`}/><Kpi icon={Droplets} label="BLOOD UNITS" value={blood} tone="red" sub="All compatible groups"/><Kpi icon={Gauge} label="HOSPITAL UTILIZATION" value={`${util}%`} tone="amber" sub="Network occupancy"/><Kpi icon={Users} label="ACTIVE RESCUE TEAMS" value="14" tone="green" sub="3 in impact zone"/><Kpi icon={BadgeIndianRupee} label="EMERGENCY FUNDS" value={`₹${(rem/100000).toFixed(1)}L`} tone="cyan" sub="Remaining allocation"/></div>
    <div className="dashboard-grid"><div className="map-panel panel"><PanelTitle icon={MapPinned} title="LIVE OPERATIONS MAP" right={<span className="live-pill small"><span className="pulse-dot"/>LIVE</span>}/><CommandMap {...props}/></div><div className="right-rail"><DecisionSpotlight {...props}/><AlertFeed alerts={props.alerts}/></div></div>
    <div className="bottom-grid"><SeverityChart patients={patients}/><HospitalCapacity hospitals={hospitals}/><ResourcePulse blood={blood} meds={props.meds}/></div>
  </div>
}

function Kpi({icon:Icon,label,value,tone,sub}:{icon:any,label:string,value:any,tone:string,sub:string}){return <motion.div className={`kpi ${tone}`} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}}><div className="kpi-top"><span className="kpi-icon"><Icon size={17}/></span><span className="trend"><TrendingUp size={12}/> live</span></div><strong>{value}</strong><b>{label}</b><small>{sub}</small></motion.div>}
function PanelTitle({icon:Icon,title,right}:{icon:any,title:string,right?:React.ReactNode}){return <div className="panel-title"><div><Icon size={16}/><b>{title}</b></div>{right}</div>}

function CommandMap(props:any){
  const {radius,epicenter,hospitals,ambulances,patients,road,severity,traffic,setSelectedHospital,setSelectedPatient}=props
  const mapRef=useRef<any>(null)
  const [selectedFacility,setSelectedFacility]=useState<FacilityModel|null>(null)
  const impact=useMemo(()=>impactZonesGeoJSON(epicenter.lng,epicenter.lat,radius,severity),[radius,severity,epicenter.lng,epicenter.lat])
  const critical=patients.filter((p:PatientModel)=>p.severity==='CRITICAL' && p.assignedHospital)
  const patientRoutes={type:'FeatureCollection' as const,features:critical.map((p:PatientModel)=>{const h=hospitals.find((x:HospitalModel)=>x.name===p.assignedHospital);return {type:'Feature' as const,properties:{kind:'patient-route'},geometry:{type:'LineString' as const,coordinates:[[p.lng,p.lat],[h?.lng||p.lng,h?.lat||p.lat]]}}})}
  const roads={type:'FeatureCollection' as const,features:roadNetworkSeed.map((r,i)=>({type:'Feature' as const,properties:{id:r.id,name:r.name,state:r.id==='R-21'?road:(i===1&&traffic>=3?'SLOW':r.state)},geometry:{type:'LineString' as const,coordinates:r.coords}}))}
  const mapStyle:any={version:8,sources:{osm:{type:'raster',tiles:['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],tileSize:256,attribution:'© OpenStreetMap contributors'}},layers:[{id:'osm',type:'raster',source:'osm',paint:{'raster-saturation':-.05,'raster-contrast':.08,'raster-brightness-min':.34,'raster-brightness-max':.96}}]}
  useEffect(()=>{const id=window.setTimeout(()=>mapRef.current?.resize(),120);return()=>window.clearTimeout(id)},[])
  const roadPaint:any={'line-color':['match',['get','state'],'CLEAR','#16a34a','SLOW','#eab308','DAMAGED','#f97316','BLOCKED','#dc2626','HIGH-RISK','#a855f7','#22d3ee'],'line-width':['match',['get','state'],'BLOCKED',7,5],'line-opacity':.92}
  return <div className="map-wrap live-map-wrap"><MapGL ref={mapRef} initialViewState={{longitude:72.8505,latitude:19.1518,zoom:11.3}} minZoom={8} maxZoom={18} dragPan={true} dragRotate={false} scrollZoom={true} doubleClickZoom={true} touchZoomRotate={true} mapStyle={mapStyle} attributionControl={true} onLoad={()=>mapRef.current?.resize()}>
    <NavigationControl position="bottom-right" showCompass={true}/><FullscreenControl position="bottom-right"/><ScaleControl position="bottom-left" maxWidth={120} unit="metric"/>
    <Source id="impact-zones" type="geojson" data={impact}>
      <Layer id="impact-warning" type="fill" filter={['==',['get','level'],'warning']} paint={{'fill-color':'#facc15','fill-opacity':0.18}}/>
      <Layer id="impact-severe" type="fill" filter={['==',['get','level'],'severe']} paint={{'fill-color':'#f97316','fill-opacity':0.24}}/>
      <Layer id="impact-critical" type="fill" filter={['==',['get','level'],'critical']} paint={{'fill-color':'#dc2626','fill-opacity':0.34}}/>
      <Layer id="impact-outline" type="line" paint={{'line-color':['match',['get','level'],'critical','#ef4444','severe','#fb923c','#fde047'],'line-width':2.2,'line-opacity':.85}}/>
    </Source>
    <Source id="road-network" type="geojson" data={roads}><Layer id="road-network-lines" type="line" paint={roadPaint}/></Source>
    <Source id="patient-routes" type="geojson" data={patientRoutes}><Layer id="patient-route-lines" type="line" paint={{'line-color':'#22d3ee','line-width':4,'line-opacity':.85,'line-dasharray':[1.2,1.1]}}/></Source>
    <Marker longitude={epicenter.lng} latitude={epicenter.lat} anchor="center"><div className="epicenter" title="Locked disaster epicenter"><span/><Flame size={16}/></div></Marker>
    {hospitals.map((h:HospitalModel)=><Marker key={h.id} longitude={h.lng} latitude={h.lat} anchor="center" onClick={(e:any)=>{e.originalEvent.stopPropagation();setSelectedHospital(h);setSelectedFacility(null)}}><button className={`marker hospital ${h.status.toLowerCase()}`} title={h.name}><Hospital size={15}/></button></Marker>)}
    {realFacilities.map(f=><Marker key={f.id} longitude={f.lng} latitude={f.lat} anchor="center" onClick={(e:any)=>{e.originalEvent.stopPropagation();setSelectedFacility(f);setSelectedHospital(null)}}><button className={`marker facility facility-${f.type}`} title={f.name}>{facilitySymbol(f.type)}</button></Marker>)}
    {ambulances.map((a:AmbulanceModel)=><Marker key={a.id} longitude={a.lng} latitude={a.lat} anchor="center"><div className={`marker ambulance ${a.available?'':'busy'}`} title={`${a.id} • ${a.type}`}><Ambulance size={14}/></div></Marker>)}
    {patients.map((p:PatientModel)=><Marker key={p.id} longitude={p.lng} latitude={p.lat} anchor="center" onClick={(e:any)=>{e.originalEvent.stopPropagation();setSelectedPatient(p)}}><div className="patient-marker" style={{borderColor:sevColor[p.severity]}} title={`${p.id} • ${p.severity}`}><Heart size={10} fill={sevColor[p.severity]} color={sevColor[p.severity]}/></div></Marker>)}
    {props.selectedHospital&&<Popup longitude={props.selectedHospital.lng} latitude={props.selectedHospital.lat} onClose={()=>setSelectedHospital(null)} closeButton={false} offset={18}><MapPopupHospital h={props.selectedHospital}/></Popup>}
    {props.selectedPatient&&<Popup longitude={props.selectedPatient.lng} latitude={props.selectedPatient.lat} onClose={()=>setSelectedPatient(null)} closeButton={false} offset={18}><MapPopupPatient p={props.selectedPatient}/></Popup>}
    {selectedFacility&&<Popup longitude={selectedFacility.lng} latitude={selectedFacility.lat} onClose={()=>setSelectedFacility(null)} closeButton={false} offset={18}><div className="popup-card"><b>{selectedFacility.name}</b><span>{selectedFacility.address}</span><div><small>Type</small><strong>{selectedFacility.type.toUpperCase()}</strong></div><div><small>Status</small><strong>{selectedFacility.status}</strong></div></div></Popup>}
  </MapGL>
  <div className="map-overlay top-left"><span><i className="red-dot"/> LOCKED RESPONSE REGION <b>WESTERN SUBURBS</b></span><span><i className="cyan-dot"/> SCALE <b>{radius} KM</b></span><span><i className="cyan-dot"/> ROAD MODEL <b>{road}</b></span></div>
  <div className="map-help">DRAG TO PAN • SCROLL TO ZOOM • DISASTER ZONE REMAINS GEO-LOCKED</div>
  <a className="google-map-link" href={`https://www.google.com/maps/@?api=1&map_action=map&center=${epicenter.lat},${epicenter.lng}&zoom=12`} target="_blank" rel="noreferrer">OPEN SAME AREA IN GOOGLE MAPS ↗</a>
  <div className="map-legend enhanced"><span><i className="legend-swatch critical"/>Critical</span><span><i className="legend-swatch severe"/>Severe</span><span><i className="legend-swatch warning"/>Warning</span><span><i className="dot hosp"/>Hospital</span><span className="legend-letter fire">F</span><span>Fire</span><span className="legend-letter police">P</span><span>Police</span><span className="legend-letter blood">B</span><span>Blood</span><span><i className="road-clear"/>Open</span><span><i className="road-blocked"/>Blocked</span></div></div>
}
function MapPopupHospital({h}:{h:HospitalModel}){return <div className="popup-card"><b>{h.name}</b><span>{h.status} • {h.availableBeds}/{h.totalBeds} beds free</span><div><small>ICU</small><strong>{h.icuAvailable}/{h.icuTotal}</strong></div><div><small>Blood</small><strong>{h.blood} units</strong></div><div><small>Incoming</small><strong>{h.incoming}</strong></div></div>}
function MapPopupPatient({p}:{p:PatientModel}){return <div className="popup-card"><b>{p.id} • {p.severity}</b><span>{p.condition}</span><div><small>Score</small><strong>{p.score}/100</strong></div><div><small>Hospital</small><strong>{p.assignedHospital||'Pending'}</strong></div><div><small>ETA</small><strong>{p.eta?`${p.eta} min`:'—'}</strong></div></div>}

function DecisionSpotlight({decisions,patients}:{decisions:Decision[],patients:PatientModel[]}){const d=decisions[0],p=d&&patients.find(x=>x.id===d.patientId);return <div className="panel decision-spot"><PanelTitle icon={ShieldCheck} title="SENTINEL DECISION ENGINE" right={<span className="ai-chip">EXPLAINABLE</span>}/>{d?<><div className="decision-head"><div><span>PATIENT</span><b>{d.patientId}</b></div><SeverityBadge s={d.severity}/></div><div className="allocation-path"><PathNode icon={HeartPulse} label={d.patientId} sub={`${p?.score||0}/100 priority`}/><span>→</span><PathNode icon={Ambulance} label={d.ambulance} sub="medical match"/><span>→</span><PathNode icon={Hospital} label={d.hospital.split(' ').slice(0,2).join(' ')} sub="capacity match"/></div><div className="decision-metrics"><div><span>ROUTE</span><b>{d.route}</b></div><div><span>ETA</span><b>{d.eta} min</b></div><div><span>STATUS</span><b>ALLOCATED</b></div></div><div className="why"><b>WHY THIS DECISION?</b>{d.reason.slice(0,4).map(r=><span key={r}><ShieldCheck size={12}/>{r}</span>)}</div></>:<div className="empty">Run allocation to generate transparent decisions.</div>}</div>}
function PathNode({icon:Icon,label,sub}:{icon:any,label:string,sub:string}){return <div><span className="path-icon"><Icon size={16}/></span><b>{label}</b><small>{sub}</small></div>}
function AlertFeed({alerts}:{alerts:AlertItem[]}){return <div className="panel alerts"><PanelTitle icon={BellRing} title="INTELLIGENT ALERTS" right={<span>{alerts.length} events</span>}/><div className="alert-list">{alerts.slice(0,6).map(a=><div className={`alert ${a.kind}`} key={a.id}><span className="alert-ico">{a.kind==='critical'?<AlertTriangle/>:a.kind==='success'?<ShieldCheck/>:<BellRing/>}</span><div><b>{a.text}</b><small>{a.time}</small></div></div>)}</div></div>}
function SeverityBadge({s}:{s:Severity}){return <span className="severity-badge" style={{color:sevColor[s],borderColor:sevColor[s]+'66',background:sevColor[s]+'12'}}><i style={{background:sevColor[s]}}/>{s}</span>}
function SeverityChart({patients}:{patients:PatientModel[]}){const data=(['CRITICAL','SEVERE','MODERATE','STABLE'] as Severity[]).map(s=>({name:s,value:patients.filter(p=>p.severity===s).length,color:sevColor[s]}));return <div className="panel chart"><PanelTitle icon={HeartPulse} title="PATIENT SEVERITY"/><div className="chart-body"><ResponsiveContainer width="58%" height={160}><PieChart><Pie data={data} dataKey="value" innerRadius={47} outerRadius={67} paddingAngle={3}>{data.map(x=><Cell key={x.name} fill={x.color}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer><div className="legend-list">{data.map(d=><span key={d.name}><i style={{background:d.color}}/>{d.name}<b>{d.value}</b></span>)}</div></div></div>}
function HospitalCapacity({hospitals}:{hospitals:HospitalModel[]}){return <div className="panel chart"><PanelTitle icon={Hospital} title="HOSPITAL OCCUPANCY"/><div className="bar-list">{hospitals.slice(0,4).map(h=>{const u=Math.round(100*(1-h.availableBeds/h.totalBeds));return <div key={h.id}><span><b>{h.name}</b><em>{u}%</em></span><div className="capacity-bar"><i style={{width:u+'%'}}/></div></div>})}</div></div>}
function ResourcePulse({blood,meds}:{blood:number,meds:number}){const data=[{n:'Blood',v:blood/5},{n:'ICU',v:62},{n:'Meds',v:meds},{n:'Amb',v:48}];return <div className="panel chart"><PanelTitle icon={Activity} title="RESOURCE PULSE"/><ResponsiveContainer width="100%" height={165}><BarChart data={data}><CartesianGrid stroke="#ffffff0a" vertical={false}/><XAxis dataKey="n" tick={{fill:'#718096',fontSize:10}} axisLine={false} tickLine={false}/><YAxis hide/><Tooltip/><Bar dataKey="v" fill="#22d3ee" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div>}

function SimulationPage(props:any){return <div className="stack"><PageHead title="Simulation Control" subtitle="Change disaster conditions and watch SENTINEL automatically recalculate patient priority, resources, hospitals, ambulances, routes and ETA." actions={<><button className="demo-btn" onClick={props.startDemo}><Play size={15}/> START DEMO</button><button className="primary" onClick={props.recalculateNow}><Zap size={15}/> RECALCULATE NOW</button></>}/><div className="speed-panel panel"><div><b>SIMULATION SPEED</b><span>Controls the live simulation clock and demo event timing. The selected speed is saved in this browser.</span></div><div className="speed-buttons">{([1,2,5,10] as const).map(x=><button key={x} className={props.speed===x?'active':''} onClick={()=>props.changeSpeed(x)}>{x}x</button>)}</div></div><div className="sim-layout"><div className="panel controls-panel"><PanelTitle icon={SlidersHorizontal} title="LIVE SCENARIO PARAMETERS"/><SelectControl label="Disaster Type" value={props.disaster} options={['Earthquake','Flood','Fire','Cyclone','Building Collapse','Industrial Accident','Terrorist Attack']} onChange={props.setDisaster}/><SliderControl label="Disaster Severity" value={props.severity} min={1} max={4} labels={['Low','Medium','High','Extreme']} onChange={(v:number)=>{props.setSeverity(v);props.pushAlert(`Disaster severity changed to ${['Low','Medium','High','Extreme'][v-1]}.`,'warn')}}/><SliderControl label="Impact Radius" value={props.radius} min={3} max={20} suffix=" km" onChange={props.setRadius}/><SliderControl label="Traffic" value={props.traffic} min={1} max={4} labels={['Low','Medium','High','Gridlock']} onChange={props.setTraffic}/><SelectControl label="Road Condition" value={props.road} options={['CLEAR','SLOW','DAMAGED','BLOCKED','HIGH-RISK']} onChange={props.setRoad}/><div className="control-actions"><button className="ghost" onClick={props.triggerIncident}><UserRoundPlus size={15}/> Trigger Incident</button><button className="ghost" onClick={()=>{props.setSeverity(Math.min(4,props.severity+1));props.setRadius(Math.min(20,props.radius+2));props.pushAlert('Disaster intensity increased; impact zone expanded.','critical')}}><AlertTriangle size={15}/> Increase Severity</button></div></div><div className="panel sim-map"><PanelTitle icon={MapPinned} title="IMPACT & RESPONSE MODEL" right={<span className="live-pill small"><span className="pulse-dot"/>SIMULATION</span>}/><CommandMap {...props}/></div></div><div className="adapt-banner"><div className="adapt-icon"><RefreshCw/></div><div><span>ADAPTIVE MODEL</span><h3>Every condition change triggers a full allocation re-evaluation.</h3><p>Patient priority → Ambulance → Hospital → Route → ETA → Resource demand</p></div><button className="primary" onClick={props.adaptModel}><Zap size={16}/> ADAPT MODEL TO SITUATION</button></div></div>}
function SliderControl({label,value,min,max,suffix='',labels,onChange}:{label:string,value:number,min:number,max:number,suffix?:string,labels?:string[],onChange:(v:number)=>void}){return <div className="control"><div className="control-label"><b>{label}</b><span>{labels?labels[value-1]:value+suffix}</span></div><input type="range" min={min} max={max} value={value} onChange={e=>onChange(Number(e.target.value))}/>{labels&&<div className="range-labels"><span>{labels[0]}</span><span>{labels[labels.length-1]}</span></div>}</div>}
function SelectControl({label,value,options,onChange}:{label:string,value:string,options:string[],onChange:(v:any)=>void}){return <label className="control"><div className="control-label"><b>{label}</b></div><select value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o}>{o}</option>)}</select></label>}

function PatientsPage(props:any){const sorted=props.patients;return <div className="stack"><PageHead title="Patient Triage & Prioritization" subtitle="Medical severity is processed before arrival order or proximity. Modify severity to see the network recalculate." actions={<><button className="primary" onClick={props.prioritizePatients}><Zap size={15}/> PRIORITIZE</button><button className="ghost" onClick={props.triggerIncident}><UserRoundPlus size={15}/> ADD SIMULATED PATIENT</button></>}/><div className="triage-principle"><ShieldCheck/><div><b>TRIAGE POLICY ACTIVE</b><span>NOT FCFS • NOT NEAREST-HOSPITAL ONLY • CLINICAL NEED FIRST</span></div></div><div className="patient-grid">{sorted.map((p:PatientModel)=><PatientCard key={p.id} p={p} updateSeverity={props.updateSeverity}/>)}</div></div>}
function PatientCard({p,updateSeverity}:{p:PatientModel,updateSeverity:(id:string,s:Severity)=>void}){return <div className={`patient-card sev-${p.severity.toLowerCase()}`}><div className="pc-head"><div><span>{p.id}</span><h3>{p.condition}</h3><small>Age {p.age} • priority score {p.score}/100</small></div><SeverityBadge s={p.severity}/></div><div className="patient-needs"><Need label="ICU" value={p.icu?'Required':'No'}/><Need label="Blood" value={p.blood?`${p.blood} unit(s)`:'No'}/><Need label="Ambulance" value={p.ambulanceNeed}/><Need label="Specialist" value={p.specialist}/></div><div className="assign-row"><span><Ambulance size={14}/>{p.assignedAmbulance||'Awaiting'}</span><span><Hospital size={14}/>{p.assignedHospital||'Awaiting allocation'}</span><span><Clock3 size={14}/>{p.eta?`${p.eta} min`:'—'}</span></div><div className="pc-footer"><label>CHANGE SEVERITY<select value={p.severity} onChange={e=>updateSeverity(p.id,e.target.value as Severity)}>{(['CRITICAL','SEVERE','MODERATE','STABLE'] as Severity[]).map(x=><option key={x}>{x}</option>)}</select></label><button className="link-btn">WHY PRIORITIZED? <ChevronRight size={13}/></button></div></div>}
function Need({label,value}:{label:string,value:string}){return <div><span>{label}</span><b>{value}</b></div>}

function HospitalsPage(props:any){const totalIcu=props.hospitals.reduce((s:number,h:HospitalModel)=>s+h.icuTotal,0),availableIcu=props.hospitals.reduce((s:number,h:HospitalModel)=>s+h.icuAvailable,0),occupiedIcu=Math.max(0,totalIcu-availableIcu),icuPct=totalIcu?Math.min(100,Math.max(0,Math.round(occupiedIcu/totalIcu*100))):0,overflow=Math.max(0,Math.round(totalIcu*.9)-occupiedIcu),turnaround=Math.max(18,Math.round(34+icuPct*.22));return <div className="stack"><PageHead title="Hospital Capacity Network" subtitle="Live capacity and projected availability after current allocations."/><div className="icu-summary"><MiniMetric icon={BedDouble} label="Total ICU beds" value={totalIcu}/><MiniMetric icon={HeartPulse} label="Occupied ICU beds" value={occupiedIcu}/><MiniMetric icon={Gauge} label="ICU occupancy" value={`${icuPct}%`}/><MiniMetric icon={AlertTriangle} label="Beds before 90% overflow" value={overflow}/><MiniMetric icon={Clock3} label="Avg turnaround" value={`${turnaround} min`}/></div><div className="hospital-grid">{props.hospitals.map((h:HospitalModel)=><HospitalCard key={h.id} h={h} onAdmit={()=>props.simulateAdmission(h.id)}/> )}</div></div>}
function HospitalCard({h,onAdmit}:{h:HospitalModel,onAdmit:()=>void}){const occ=Math.round(100*(1-h.availableBeds/h.totalBeds)),icuOcc=Math.round(100*(1-h.icuAvailable/h.icuTotal));return <div className="hospital-card"><div className="hc-head"><div className="hc-icon"><Hospital/></div><div><h3>{h.name}</h3><span>{h.currentPatients} patients • {h.incoming} incoming</span></div><StatusChip status={h.status}/></div><div className="capacity-block"><div><span>BED OCCUPANCY</span><b>{occ}%</b></div><div className="capacity-bar"><i style={{width:occ+'%'}}/></div><small>{h.availableBeds} available of {h.totalBeds}</small></div><div className="capacity-block"><div><span>ICU CAPACITY</span><b>{icuOcc}%</b></div><div className="capacity-bar red"><i style={{width:icuOcc+'%'}}/></div><small>{h.icuAvailable} ICU beds available of {h.icuTotal}</small></div><div className="hospital-stats"><Need label="Blood stock" value={`${h.blood} units`}/><Need label="Ventilators" value={`${h.ventilators}`}/><Need label="Projected free beds" value={`${Math.max(0,h.availableBeds-h.incoming)}`}/></div><div className="specialists">{h.specialists.map(s=><span key={s}>{s}</span>)}</div><button className="ghost wide" onClick={onAdmit}>SIMULATE ADMISSION</button></div>}
function StatusChip({status}:{status:HospitalStatus}){return <span className={`status-chip ${status.toLowerCase()}`}><i/>{status}</span>}

function ResourcesPage(props:any){const icu=props.hospitals.reduce((s:number,h:HospitalModel)=>s+h.icuAvailable,0),totalIcu=props.hospitals.reduce((s:number,h:HospitalModel)=>s+h.icuTotal,0);return <div className="stack"><PageHead title="Resource Management" subtitle="Demand-vs-availability view synchronized with the active response model."/><div className="resource-grid"><ResourceCard icon={Droplets} title="BLOOD" value={props.blood} unit="units available" total={560} demand={182} tone="red" onMinus={()=>props.setBlood((v:number)=>Math.max(0,v-25))}/><ResourceCard icon={BedDouble} title="ICU BEDS" value={icu} unit="beds available" total={totalIcu} demand={31} tone="cyan"/><ResourceCard icon={Pill} title="MEDICINES" value={`${props.meds}%`} unit="stock readiness" total={100} demand={72} tone="amber" onMinus={()=>props.setMeds((v:number)=>Math.max(0,v-10))}/><ResourceCard icon={BadgeIndianRupee} title="EMERGENCY FUNDS" value={`₹${((props.funds.total-props.funds.hospital-props.funds.ambulance-props.funds.medicines-props.funds.rescue-props.funds.ngo)/100000).toFixed(1)}L`} unit="remaining" total={50} demand={39} tone="green"/></div><div className="panel"><PanelTitle icon={Activity} title="MEDICINE INVENTORY — AVAILABLE → REQUIRED → SHORTAGE"/><div className="medicine-table"><MedRow name="Antibiotics" have={720} need={430}/><MedRow name="Pain medication" have={940} need={610}/><MedRow name="Emergency drugs" have={260} need={245}/><MedRow name="IV fluids" have={510} need={590}/><MedRow name="Trauma kits" have={145} need={138}/></div></div></div>}
function ResourceCard({icon:Icon,title,value,unit,total,demand,tone,onMinus}:{icon:any,title:string,value:any,unit:string,total:number,demand:number,tone:string,onMinus?:()=>void}){const p=Math.min(100,Math.round(demand/total*100));return <div className={`resource-card ${tone}`}><div className="rc-head"><span><Icon/></span><b>{title}</b><em>LIVE</em></div><strong>{value}</strong><small>{unit}</small><div className="demand-row"><span>DEMAND</span><b>{demand}</b><span>AVAILABLE INDEX</span><b>{Math.max(0,total-demand)}</b></div><div className="capacity-bar"><i style={{width:p+'%'}}/></div>{onMinus&&<button className="ghost wide" onClick={onMinus}>SIMULATE RESOURCE DROP</button>}</div>}
function MedRow({name,have,need}:{name:string,have:number,need:number}){const shortage=Math.max(0,need-have);return <div><b>{name}</b><span className="green-text">{have}</span><ChevronRight/><span>{need}</span><ChevronRight/><span className={shortage?'red-text':'green-text'}>{shortage||'No shortage'}</span></div>}

function AmbulancesPage(props:any){return <div className="stack"><PageHead title="Ambulance Fleet" subtitle="Vehicle selection follows the patient's required medical support — not random assignment."/><div className="ambulance-summary"><MiniMetric icon={Ambulance} label="Fleet total" value={props.ambulances.length}/><MiniMetric icon={ShieldCheck} label="Available" value={props.ambulances.filter((a:AmbulanceModel)=>a.available).length}/><MiniMetric icon={Navigation} label="Assigned / en route" value={props.ambulances.filter((a:AmbulanceModel)=>!a.available).length}/><MiniMetric icon={HeartPulse} label="Advanced-capability units" value={props.ambulances.filter((a:AmbulanceModel)=>a.type!=='BASIC').length}/></div><div className="ambulance-grid">{props.ambulances.map((a:AmbulanceModel)=><div className={`amb-card ${a.available?'':'assigned'}`} key={a.id}><div className="amb-head"><span className="ambulance-visual"><Ambulance/></span><div><h3>{a.id}</h3><b>{a.type==='ALS'?'Advanced Life Support':a.type==='ICU'?'ICU Ambulance':a.type==='NEONATAL'?'Neonatal Ambulance':'Basic Ambulance'}</b></div><span className={`availability ${a.available?'yes':'no'}`}>{a.available?'AVAILABLE':'TASKED'}</span></div><div className="equipment">{a.equipment.map(e=><span key={e}>{e}</span>)}</div><div className="amb-details"><Need label="Patient" value={a.patient||'—'}/><Need label="Destination" value={a.destination||'Standby'}/><Need label="ETA" value={a.eta?`${a.eta} min`:'—'}/></div></div>)}</div></div>}
function MiniMetric({icon:Icon,label,value}:{icon:any,label:string,value:any}){return <div><Icon/><span>{label}</span><b>{value}</b></div>}

function MapRoutesPage(props:any){return <div className="stack"><PageHead title="Map & Adaptive Routes" subtitle="Road condition, traffic, disaster impact and distance all affect travel time and route choice."/><div className="map-routes-layout"><div className="panel big-map"><CommandMap {...props}/></div><div className="route-side"><div className="panel"><PanelTitle icon={Route} title="ROUTE CONDITIONS"/><RoadRow name="Western Relief Corridor" state={props.road} eta={13}/><RoadRow name="Link Road Response Lane" state={props.traffic>2?'SLOW':'CLEAR'} eta={11+props.traffic*2}/><RoadRow name="Impact-Zone Connector" state={props.severity>2?'HIGH-RISK':'CLEAR'} eta={16+props.severity*2}/><RoadRow name="R-21 Underpass" state={props.road==='BLOCKED'?'BLOCKED':'DAMAGED'} eta={props.road==='BLOCKED'?0:19}/></div><div className="panel"><PanelTitle icon={Navigation} title="WHY ROUTE B?"/><div className="route-why"><b>Shortest ≠ fastest or safest</b><p>Route selection evaluates traffic, damaged surfaces, blocked segments and exposure to the disaster impact zone.</p><div><span>Route A</span><em>5.4 km • heavy • damaged</em><b>19 min</b></div><div className="selected"><span>Route B</span><em>7.8 km • moderate • clear</em><b>12 min</b></div></div></div></div></div></div>}
function RoadRow({name,state,eta}:{name:string,state:string,eta:number}){return <div className="road-row"><span className={`road-dot ${state.toLowerCase().replace('-','')}`}/><div><b>{name}</b><small>{state}</small></div><strong>{eta?`${eta} min`:'NO ACCESS'}</strong></div>}

function FundsPage(props:any){const f=props.funds, rem=f.total-f.hospital-f.ambulance-f.medicines-f.rescue-f.ngo;const items=[['Hospital Support','hospital'],['Ambulance Operations','ambulance'],['Medicine Procurement','medicines'],['Rescue Operations','rescue'],['NGO Support','ngo']] as const;const data=items.map(([n,k])=>({name:n,value:f[k]}));return <div className="stack"><PageHead title="Emergency Funds" subtitle="Interactive financial allocation model linked to response operations."/><div className="fund-hero"><div><span>TOTAL EMERGENCY FUND POOL</span><strong>₹{(f.total/100000).toFixed(0)},00,000</strong><small>Scenario budget • dynamically consumed by operations</small></div><div><span>REMAINING</span><strong>₹{(rem/100000).toFixed(1)}L</strong><small>{Math.round(rem/f.total*100)}% available</small></div></div><div className="fund-grid"><div className="panel"><PanelTitle icon={CircleDollarSign} title="ALLOCATION CONTROL"/>{items.map(([n,k])=><label className="fund-row" key={k}><div><b>{n}</b><span>₹{(f[k]/100000).toFixed(1)}L</span></div><input type="range" min={0} max={1500000} step={50000} value={f[k]} onChange={e=>props.setFunds((x:any)=>({...x,[k]:Number(e.target.value)}))}/></label>)}</div><div className="panel"><PanelTitle icon={BadgeIndianRupee} title="SPEND DISTRIBUTION"/><ResponsiveContainer width="100%" height={300}><PieChart><Pie data={data} dataKey="value" innerRadius={70} outerRadius={105} paddingAngle={2}>{data.map((_,i)=><Cell key={i} fill={['#22d3ee','#3b82f6','#f59e0b','#fb7185','#34d399'][i]}/>)}</Pie><Tooltip formatter={(v:any)=>`₹${(v/100000).toFixed(1)}L`}/></PieChart></ResponsiveContainer></div></div></div>}

function DecisionsPage(props:any){return <div className="stack"><PageHead title="Allocation Decisions" subtitle="Every patient allocation is clinically prioritized, resource-aware, route-aware and explainable." actions={<button className="primary" onClick={()=>props.recompute()}><Zap size={15}/> RECOMPUTE ALL</button>}/><div className="panel decision-table"><div className="table-head"><span>Patient</span><span>Severity</span><span>Ambulance</span><span>Hospital</span><span>Route</span><span>ETA</span><span>Status</span><span/></div>{props.decisions.map((d:Decision)=><div className="table-row" key={d.id}><b>{d.patientId}</b><SeverityBadge s={d.severity}/><span>{d.ambulance}</span><span>{d.hospital}</span><span>{d.route}</span><b>{d.eta} min</b><span className="status-chip available"><i/>Allocated</span><button className="link-btn">WHY?</button></div>)}{!props.decisions.length&&<div className="empty">No allocations yet. Run the decision engine.</div>}</div><div className="candidate-panel panel"><PanelTitle icon={Stethoscope} title="EXAMPLE HOSPITAL SUITABILITY — P-104"/><div className="candidate-grid"><Candidate name="Hospital A" distance="4.2 km" time="24 min" icu="Available" blood="Low" road="Partially blocked" selected={false}/><Candidate name="Hospital B" distance="7.1 km" time="14 min" icu="Available" blood="Available" road="Clear" selected/><div className="selection-reason"><ShieldCheck/><b>Hospital B selected despite being farther away.</b><p>Better blood readiness, clear road access and a 10-minute faster real travel time make it clinically safer.</p></div></div></div></div>}
function Candidate({name,distance,time,icu,blood,road,selected}:{name:string,distance:string,time:string,icu:string,blood:string,road:string,selected?:boolean}){return <div className={`candidate ${selected?'selected':''}`}><div><b>{name}</b>{selected&&<span>SELECTED</span>}</div><Need label="Distance" value={distance}/><Need label="Travel time" value={time}/><Need label="ICU" value={icu}/><Need label="Blood" value={blood}/><Need label="Road" value={road}/></div>}

function HistoryPage(props:any){const events: {time:string,title:string,text:string,kind:string}[]=[];props.decisions.slice(0,5).forEach((d:Decision,i:number)=>{events.push({time:nowTime(),title:`${d.patientId} prioritized as ${d.severity}`,text:`Priority score evaluated before distance or arrival order.`,kind:'patient'},{time:nowTime(),title:`${d.ambulance} assigned`,text:`Vehicle selected for medical capability match.`,kind:'amb'},{time:nowTime(),title:`${d.hospital} selected`,text:`Capacity, resources and route conditions accepted.`,kind:'hospital'})});return <div className="stack"><PageHead title="Decision History & Transparent Ledger" subtitle="Tamper-evident-looking audit trail for every allocation and reallocation. No blockchain security is claimed."/><div className="history-layout"><div className="panel"><PanelTitle icon={History} title="LIVE DECISION TIMELINE"/><div className="timeline">{events.slice(0,12).map((e,i)=><div className="timeline-item" key={i}><div className="timeline-time">{e.time}</div><span className="timeline-dot"/><div><b>{e.title}</b><p>{e.text}</p></div></div>)}{!events.length&&<div className="empty">Decision events will appear after allocation.</div>}</div></div><div className="panel ledger"><PanelTitle icon={ShieldCheck} title="TRANSPARENT LEDGER" right={<span className="ai-chip">AUDITABLE</span>}/>{props.decisions.map((d:Decision)=><div className="ledger-row" key={d.id}><div><span>DECISION ID</span><b>{d.id}</b></div><div><span>PATIENT</span><b>{d.patientId}</b></div><div><span>STATE TRANSITION</span><b>Awaiting → Allocated</b></div><div><span>ROUTE / ETA</span><b>{d.route} • {d.eta} min</b></div></div>)}</div></div></div>}

function PageHead({title,subtitle,actions}:{title:string,subtitle:string,actions?:React.ReactNode}){return <div className="page-head"><div><span className="eyebrow">SENTINEL OPERATIONS MODULE</span><h2>{title}</h2><p>{subtitle}</p></div>{actions&&<div className="actions">{actions}</div>}</div>}
